--[[
    OTC Hub v1.0.4 - Test Script
    by Aerlro

    This script checks the UI elements and public API.
    It does not modify gameplay or automate game actions.
]]

local SOURCE = "https://raw.githubusercontent.com/Aerlro/OTC-Hub-v1/main/otc.lua"
local TEST_CONFIG = "OTC_1.0.4_Test"

local function log(label, value)
    print("[OTC 1.0.4 TEST] " .. tostring(label), value)
end

local loaded, OTC = pcall(function()
    local source = game:HttpGet(SOURCE)
    local chunk = loadstring(source)
    assert(chunk, "Could not compile otc.lua")
    return chunk()
end)

if not loaded or type(OTC) ~= "table" then
    warn("[OTC 1.0.4 TEST] Library load failed: " .. tostring(OTC))
    return
end

print("========== OTC HUB 1.0.4 TEST ==========")
log("Loaded version", OTC.Version)

local windowOK, Window = pcall(function()
    return OTC:CreateWindow({
        Name = "OTC Hub 1.0.4",
        Subtitle = "Library Test Suite",
        Theme = "Default",
        ToggleKey = Enum.KeyCode.RightControl,
        Configuration = {
            AutoSave = false,
            AutoLoad = false,
            FileName = TEST_CONFIG
        }
    })
end)

if not windowOK or not Window then
    warn("[OTC 1.0.4 TEST] Window creation failed: " .. tostring(Window))
    return
end

local Main = Window:CreateTab({Name = "Main", Icon = "house"})
local Elements = Window:CreateTab({Name = "Elements", Icon = "layout-grid"})
local Themes = Window:CreateTab({Name = "Themes", Icon = "palette"})
local Config = Window:CreateTab({Name = "Config", Icon = "save"})
local API = Window:CreateTab({Name = "API", Icon = "code"})

-- Main / visual smoke tests
Main:CreateSection("Library Status")
Main:CreateText("OTC Hub v1.0.4 test suite loaded. Try each button and element.")
Main:CreateDivider()

Main:CreateButton({
    Name = "Notification Test",
    Description = "Checks the notification system.",
    Callback = function()
        local ok, result = pcall(function()
            OTC:Notify({Title = "OTC Hub 1.0.4", Content = "Notification system is working.", Duration = 3})
        end)
        log("Notify", ok and "PASS" or result)
    end
})

Main:CreateButton({
    Name = "Dialog Test",
    Description = "Opens a confirmation dialog.",
    Callback = function()
        local ok, result = pcall(function()
            Window:Dialog({
                Title = "Dialog Test",
                Content = "If this dialog appears, the dialog UI is working.",
                Buttons = {
                    {Name = "Cancel"},
                    {Name = "Confirm", Primary = true, Callback = function()
                        OTC:Notify({Title = "Dialog Test", Content = "Confirm callback works.", Duration = 2})
                    end}
                }
            })
        end)
        log("Dialog", ok and "OPENED" or result)
    end
})

Main:CreateButton({
    Name = "Minimize / Restore",
    Description = "Minimizes, then restores the window.",
    Callback = function()
        local ok, result = pcall(function()
            Window:Minimize()
            task.wait(0.8)
            Window:Restore()
        end)
        log("Minimize/Restore", ok and "PASS" or result)
    end
})

Main:CreateButton({
    Name = "Toggle Window",
    Description = "Hides or shows the window.",
    Callback = function()
        local ok, result = pcall(function()
            Window:Toggle()
        end)
        log("Window Toggle", ok and "PASS" or result)
    end
})

-- Element tests
Elements:CreateSection("Core Elements")
Elements:CreateText("Interact with each control and check the executor console for callback logs.")

Elements:CreateButton({
    Name = "Button Test",
    Callback = function()
        log("Button callback", "PASS")
        OTC:Notify({Title = "Button Test", Content = "Button callback fired.", Duration = 2})
    end
})

Elements:CreateToggle({
    Name = "Toggle Test",
    Description = "Switch this on and off.",
    CurrentValue = false,
    Flag = "TestToggle",
    Callback = function(value)
        log("Toggle callback", value)
    end
})

Elements:CreateSlider({
    Name = "Slider Test",
    Description = "Move from 0 to 100.",
    Range = {0, 100},
    Increment = 1,
    CurrentValue = 50,
    Flag = "TestSlider",
    Callback = function(value)
        log("Slider callback", value)
    end
})

Elements:CreateDropdown({
    Name = "Dropdown Test",
    Description = "Single selection.",
    Options = {"Alpha", "Bravo", "Charlie"},
    CurrentOption = "Alpha",
    MultiSelect = false,
    Flag = "TestDropdown",
    Callback = function(value)
        log("Dropdown callback", value)
    end
})

Elements:CreateDropdown({
    Name = "Multi Dropdown Test",
    Description = "Select more than one option.",
    Options = {"Red", "Green", "Blue"},
    CurrentOption = {},
    MultiSelect = true,
    Flag = "TestMultiDropdown",
    Callback = function(value)
        log("Multi dropdown callback", value)
    end
})

Elements:CreateInput({
    Name = "Input Test",
    Description = "Enter text and submit it.",
    Placeholder = "Type something...",
    CurrentValue = "",
    Flag = "TestInput",
    Callback = function(value)
        log("Input callback", value)
    end
})

Elements:CreateKeybind({
    Name = "Keybind Test",
    Description = "Default key is F.",
    Default = Enum.KeyCode.F,
    Flag = "TestKeybind",
    Callback = function(key)
        log("Keybind callback", key and key.Name or key)
    end
})

Elements:CreateColorpicker({
    Name = "Color Picker Test",
    Description = "Change the selected color.",
    Default = Color3.fromRGB(0, 200, 255),
    Flag = "TestColor",
    Callback = function(value)
        log("Color picker callback", value)
    end
})

local statOK, stat = pcall(function()
    return Elements:CreateStat({Name = "Stat Test", Value = "0"})
end)
log("Stat element", statOK and "CREATED" or stat)
if statOK and stat and stat.SetValue then
    pcall(function() stat:SetValue("1.0.4 OK") end)
end

local progressOK, progress = pcall(function()
    return Elements:CreateProgress({Name = "Progress Test", Value = 25, Maximum = 100})
end)
log("Progress element", progressOK and "CREATED" or progress)

local imageOK, imageResult = pcall(function()
    return Elements:CreateImage({Name = "Logo Test", Image = "rbxassetid://95900623719417"})
end)
log("Image element", imageOK and "CREATED" or imageResult)

local paragraphOK, paragraphResult = pcall(function()
    return Elements:CreateParagraph({Title = "Paragraph Test", Content = "Paragraph element check."})
end)
log("Paragraph element", paragraphOK and "CREATED" or paragraphResult)

-- Theme tests
Themes:CreateSection("Theme System")
Themes:CreateText("Use the dropdown or buttons to change the active theme.")

local themeNames = {}
local themesOK, themesResult = pcall(function()
    themeNames = OTC:GetThemes() or {}
end)
log("GetThemes", themesOK and (#themeNames .. " themes") or themesResult)

Themes:CreateDropdown({
    Name = "Theme Selector",
    Options = themeNames,
    CurrentOption = "Default",
    MultiSelect = false,
    Callback = function(value)
        local themeName = type(value) == "table" and value[1] or value
        if themeName then
            local ok, result = pcall(function() return OTC:SetTheme(themeName) end)
            log("SetTheme " .. tostring(themeName), ok and tostring(result) or result)
        end
    end
})

Themes:CreateButton({
    Name = "Get Current Theme",
    Callback = function()
        local ok, result = pcall(function() return OTC:GetTheme() end)
        log("GetTheme", ok and tostring(result) or result)
    end
})

-- Config and flags tests
Config:CreateSection("Flags and Config")
Config:CreateText("Config save/load may depend on executor file APIs being available.")

Config:CreateButton({
    Name = "Set Test Flags",
    Callback = function()
        OTC:SetFlag("TestBool", true)
        OTC:SetFlag("TestNumber", 123)
        OTC:SetFlag("TestString", "OTC 1.0.4")
        OTC:SetFlag("TestTable", {"A", "B"})
        log("SetFlag", "PASS")
    end
})

Config:CreateButton({
    Name = "Read Test Flags",
    Callback = function()
        log("GetFlag bool", OTC:GetFlag("TestBool"))
        log("GetFlag number", OTC:GetFlag("TestNumber"))
        log("GetFlag string", OTC:GetFlag("TestString"))
        log("GetFlag missing/default", OTC:GetFlag("NotSet", "fallback"))
    end
})

Config:CreateButton({
    Name = "Save Test Config",
    Callback = function()
        local ok, result = pcall(function() return OTC:SaveConfig(TEST_CONFIG) end)
        log("SaveConfig", ok and tostring(result) or result)
    end
})

Config:CreateButton({
    Name = "Load Test Config",
    Callback = function()
        local ok, result = pcall(function() return OTC:LoadConfig(TEST_CONFIG) end)
        log("LoadConfig", ok and tostring(result) or result)
    end
})

Config:CreateButton({
    Name = "List Configs",
    Callback = function()
        local ok, result = pcall(function() return OTC:GetConfigs() end)
        log("GetConfigs", ok and tostring(result) or result)
    end
})

Config:CreateButton({
    Name = "Export Test Config",
    Callback = function()
        local ok, result = pcall(function() return OTC:ExportConfig(TEST_CONFIG) end)
        if ok and type(result) == "string" then
            log("ExportConfig", "PASS (" .. #result .. " chars)")
        else
            log("ExportConfig", ok and tostring(result) or result)
        end
    end
})

Config:CreateButton({
    Name = "Delete Test Config",
    Description = "Deletes only the test config created by this script.",
    Callback = function()
        local ok, result = pcall(function() return OTC:DeleteConfig(TEST_CONFIG) end)
        log("DeleteConfig", ok and tostring(result) or result)
    end
})

-- Public API tests
API:CreateSection("Runtime API")
API:CreateButton({
    Name = "Check Version",
    Callback = function()
        log("Version", OTC.Version)
        log("Library name", OTC.Name)
    end
})

API:CreateButton({
    Name = "Check Window Theme",
    Callback = function()
        local ok, result = pcall(function() return Window:GetTheme() end)
        log("Window:GetTheme", ok and tostring(result) or result)
    end
})

API:CreateButton({
    Name = "Search UI Test",
    Callback = function()
        local ok, result = pcall(function() return Window:Search("Toggle") end)
        log("Window:Search", ok and tostring(result) or result)
    end
})

OTC:Notify({
    Title = "OTC Hub 1.0.4",
    Content = "Test suite loaded. Open Main, Elements, Themes, Config and API.",
    Duration = 5
})

print("========== OTC HUB 1.0.4 TEST READY ==========")
print("[OTC 1.0.4 TEST] Run the buttons manually; results appear in the console.")
